
// Ionic Starter App

angular.module('helx.controllers', [])

.controller('AppCtrl', function($scope, $ionicGesture, $ionicModal, $ionicPopover, $state) {

  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //$scope.$on('$ionicView.enter', function(e) {
  //});
  //  $scope.$on('$ionicView.enter', function(e) {
  //    console.log('I was loaded when this was view loaded.');
  //  });
// Go to Splash page
//$state.go('app.splash');

// Check view State
//$state.is('app.splash');

$scope.hiddenElement = function(){
  // return "ng-hide";
  if ($state.is('app.main')){
    return "ng-hide";
  } else {
    return "ng-show";
  }
}

$scope.slide={Up:false};
$scope.rotate={Flip:false};

// An array setup for checking a toggle state
$scope.ultrasoundTapCount = [];

  // Drag up Product animation
    $scope.onTap = function (){
       if(!$scope.ultrasoundTapCount['1']){
         $scope.slide.Up=true;
         $scope.rotate={Flip:true};
         console.log('Hey you tapped me up. Great!');
         $scope.ultrasoundTapCount['1'] = 1;
       }else{
         $scope.slide.Up=false;
         $scope.rotate={Flip:false};
         console.log('Then you tapped me Down. Even better!');
         $scope.ultrasoundTapCount['1'] = 0;
       }
   }
    $scope.onSwipeUp = function(){
      $scope.slide.Up=true;
      $scope.rotate={Flip:true};
      console.log('You Swiped Up.');
    }
    $scope.onSwipeLeft = function(){
      $scope.slide.Up=true;
      $scope.rotate={Flip:true};
      console.log('You Swiped Left.');
    }
    $scope.onSwipeRight = function(){
      $scope.slide.Up=true;
      $scope.rotate={Flip:true};
      console.log('You Swiped Right.');
    }
    // Drag up Product animation
    $scope.onDragDown = function(){
      $scope.slide.Up=false;
      $scope.rotate={Flip:false};
      console.log('You Draged it Down!');
    }

    $scope.hoverItem = function(hovered){
        if (hovered) {
          element.addClass('circle-hover');
        }
        else{
          element.removeClass('circle-hover');
        }
     }

  // Sub Menu Controller
  $ionicPopover.fromTemplateUrl('sub-menu.html', {
    scope: $scope
  }).then(function(popover) {
    $scope.popover = popover;
  });

  $scope.subMenu = function($event) {
    $scope.popover.show($event);
  };
  $scope.closesubMenu = function($event) {
    $scope.popover.hide($event);
  };
  //Cleanup the popover when we're done with it!
  $scope.$on('$destroy', function($event) {
    $scope.popover.remove($event);
  });
  // Execute action on hide popover
  $scope.$on('popover.hidden', function() {
    // Execute action
  });
  // Execute action on remove popover
  $scope.$on('popover.removed', function() {
    // Execute action
  });

 // Menu Links - Denoted By {{ }} //Example is {{main_menu}}
	  $scope.main_menu = '#/app/main';
	  $scope.helx_touch = '#/app/products/ultrasound';

    // Sales Quiz Page
    $scope.sales_quiz = '#/app/sales-quiz-intro';
    $scope.quiz_start = '#/app/quiz';
    $scope.quiz_correct = '#/app/correct';
    $scope.quiz_wrong = '#/app/wrong';
    $scope.quiz_question2 = '#/app/question-2';

    // Workflow Simulation Page
	  $scope.workflow = '#/app/workflow';

    // Resource library Page
    $scope.resource_library = '#/app/library';
    $scope.library_clinical = '#/app/clinical-images';
    $scope.library_videos = '#/app/clinical-videos';
    $scope.library_literature = '#/app/clinical-literature';


	  $scope.data_proof = '#/app/data';
    $scope.usability = '#/app/usability';

    // Siemens Ultasound Information
    $scope.siemens_information = '#/app/siemens-information';
    $scope.contact = '#/app/contact';
    $scope.learnmore = '#/app/learn-more';

    // System Family Tree
    $scope.system_tree = '#/app/system';
    $scope.system_tree_main = '#/app/system-main';

    // Single Product Pages
    $scope.acuson_s3000 ='#/app/acuson/s3000';
    $scope.acuson_s2000 ='#/app/acuson/s2000';
    $scope.acuson_s1000 ='#/app/acuson/s1000';


    // Create the login modal that we will use later
    $ionicModal.fromTemplateUrl('modals/modal-helx-info.html', {
      scope: $scope
      }).then(function(modal) {
        $scope.modal = modal;
    });

    // Open the login modal
    $scope.HelxInfoModal = function($helxInfo) {
     $scope.modal.show($helxInfo);
    };
    // Triggered in the login modal to close it
    $scope.closeHelxInfoModal = function($helxInfo) {
     $scope.modal.hide($helxInfo);
    };
    //Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function($helxInfo) {
      $scope.modal.remove($helxInfo);
    });
    // Execute action on hide modal
    $scope.$on('modal.hidden', function() {
      // Execute action
    });
    // Execute action on remove modal
    $scope.$on('modal.removed', function() {
      // Execute action
    });



})

.controller('DescriptionCtrl', function($scope, $ionicPopover) {

	// Description Popover Controller
  $ionicPopover.fromTemplateUrl('templates/description.html', {
    scope: $scope
	  }).then(function(popover) {
		$scope.popover = popover;
	  });

  $scope.Description = function($descriptionEvent) {
    $scope.popover.show($descriptionEvent);
  };
  $scope.closeDescription = function($descriptionEvent) {
    $scope.popover.hide($descriptionEvent);
  };
  //Cleanup the popover when we're done with it!
  $scope.$on('$destroy', function($descriptionEvent) {
    $scope.popover.remove($descriptionEvent);
  });
  // Execute action on hide popover
  $scope.$on('popover.hidden', function($descriptionEvent) {
    // Execute action
  });
  // Execute action on remove popover
  $scope.$on('popover.removed', function($descriptionEvent) {
    // Execute action
  });

})

.controller('RotateViewCtrl', function($scope, $ionicModal) {

	// Description Popover Controller
  $ionicModal.fromTemplateUrl('templates/helx-360-view.html', {
    scope: $scope
	  }).then(function(modal) {
		$scope.modal = modal;
	  });

  $scope.RotateView = function($rotateViewEvent) {
    $scope.modal.show($rotateViewEvent);
  };
  $scope.closeRotateView = function($rotateViewEvent) {
    $scope.modal.hide($rotateViewEvent);
  };
  //Cleanup the modal when we're done with it!
  $scope.$on('$destroy', function($rotateViewEvent) {
    $scope.modal.remove($rotateViewEvent);
  });
  // Execute action on hide modal
  $scope.$on('modal.hidden', function() {
    // Execute action
  });
  // Execute action on remove modal
  $scope.$on('modal.removed', function() {
    // Execute action
  });
})

.controller('ultrasoundToolCtrl', function($scope, $ionicPopover) {

	// Description Popover Controller
  $ionicPopover.fromTemplateUrl('templates/ultrasound-tool.html', {
    scope: $scope
	  }).then(function(popover) {
		$scope.popover = popover;
	  });

  $scope.ultrasoundTool = function($ultrasoundToolEvent) {
    $scope.popover.show($ultrasoundToolEvent);
  };
  $scope.closeultrasoundTool = function($ultrasoundToolEvent) {
    $scope.popover.hide($ultrasoundToolEvent);
  };
  //Cleanup the popover when we're done with it!
  $scope.$on('$destroy', function($ultrasoundToolEvent) {
    $scope.popover.remove($ultrasoundToolEvent);
  });
  // Execute action on hide popover
  $scope.$on('popover.hidden', function($ultrasoundToolEvent) {
    // Execute action
  });
  // Execute action on remove popover
  $scope.$on('popover.removed', function($ultrasoundToolEvent) {
    // Execute action
  });

  $scope.ultrasoundToolsList = [
    {
        Id: 1,
        Image: "../img/accessories/18L6.png",
        Title: "18L6 HD",
        Attributes: "Curabitur elementum"
    },
    {
        Id: 1,
        Image: "../img/accessories/4c1.png",
        Title: "18L6 HD",
        Attributes: "Curabitur elementum"
    },
    {
        Id: 1,
        Image: "../img/accessories/12l4.png",
        Title: "18L6 HD",
        Attributes: "Curabitur elementum"
    }
  ];

})


.controller('HelxOverviewCtrl', function($scope, $ionicModal, $state, $ionicSlideBoxDelegate, $timeout) {

  // Description HELX Overview Modal Controller
  $ionicModal.fromTemplateUrl('templates/helx-overview.html', {
    scope: $scope
	  }).then(function(modal) {
      $scope.modal = modal;
      if($state.is('app.products.ultrasound')){
          $timeout(function () {
            $scope.modal.show();
          }, 1100);

        }
  });
  $scope.close={Modal:false};

  $scope.OverView = function($OverViewEvent) {
    $scope.modal.show($OverViewEvent);
  }
  $scope.closeOverView = function($OverViewEvent) {
    $scope.modal.hide($OverViewEvent);
    $scope.close={Modal:true};
    $scope.animate={Footer:true};
  }
  //Cleanup the modal when we're done with it!
  $scope.$on('$destroy', function($OverViewEvent) {
    $scope.modal.remove($OverViewEvent);
  });
  // Execute action on hide modal
  $scope.$on('modal.hidden', function() {
    $scope.close={Modal:true};
    // Execute action
  });
  // Execute action on remove modal
  $scope.$on('modal.removed', function() {
    // Execute action
  });

    //Go to Feature and load correct slide
      function Slides(index) {
      //Go to Feature from icon click
      $scope.feature0 = function() {
        $scope.activeSlide = index = 0 ;
      };
      $scope.feature1 = function() {
        $scope.activeSlide = index = 1 ;
      };
      $scope.feature2 = function() {
        $scope.activeSlide = index = 2 ;
      };
      $scope.feature3 = function() {
        $scope.activeSlide = index = 3 ;
      };
      $scope.feature4 = function() {
        $scope.activeSlide = index = 4 ;
      };
      $scope.feature5 = function() {
        $scope.activeSlide = index = 5 ;
      };
        $scope.activeSlide = index;
      console.log("This slide is " + index);
    }

    setTimeout(function() {
        Slides($scope.activeSlide);
    }, 400);

    $scope.slideChanged = Slides;
})


.controller('FeaturesCtrl', function($scope, $ionicPopover) { })


.controller('ClinicalImagesCtrl', function($scope, $http, $location, $timeout, $ionicModal ) {

  $http.get('data/library.json').then(function (res) {
      $scope.Clinical = res.data.Clinical;
      $scope.filteredSlides = $scope.Clinical.slice(begin, end);
  });

  // Description Popover Controller
  $ionicModal.fromTemplateUrl('templates/modals/modal-clinical-images.html', {
    scope: $scope
	  }).then(function(modal) {
		$scope.modal = modal;
	  });

  $scope.clinicalImageModal = function($clinicalImageModalEvent) {
    $scope.modal.show($clinicalImageModalEvent);
  };
  $scope.closeClinicalImageModal = function($clinicalImageModalEvent) {
    $scope.modal.hide($clinicalImageModalEvent);
  };
  //Cleanup the modal when we're done with it!
  $scope.$on('$destroy', function($clinicalImageModalEvent) {
    $scope.modal.remove($clinicalImageModalEvent);
  });
  // Execute action on hide modal
  $scope.$on('modal.hidden', function() {
    // Execute action
  });
  // Execute action on remove modal
  $scope.$on('modal.removed', function() {
    // Execute action
  });

  //Go page slider next and prev functions
    function clinicalSlider(index) {

        $scope.prevSlide = function() {
          $scope.activeSlide = index - 1 ;
        };
        $scope.nextSlide = function() {
          $scope.activeSlide = index + 1 ;
        };
    }
    $scope.activeSlide = 0;

    setTimeout(function() {
      clinicalSlider($scope.activeSlide);
    }, 0);

})

.controller('clinicalModalSlider', function($scope) {
  // Modal slider next and prev functions
    function clinicalModalSlider(index) {

        $scope.prevSlideModal = function() {
          $scope.activeSlide = index - 1 ;
        };
        $scope.nextSlideModal = function() {
          $scope.activeSlide = index + 1 ;
        };
    }
    $scope.activeSlide = 0;

    setTimeout(function() {
      clinicalModalSlider($scope.activeSlide);
    }, 0);

    $scope.slideChanged = clinicalModalSlider;
})


.controller('systemCtrl', function($scope, $http, $location, $timeout, $ionicModal ) {

  $scope.disabled={vc31:false};
  $scope.disabled={vc20a:false};
  $scope.disabled={vc25a:false};
  $scope.disabled={vc30a:false};
  $scope.disabled={vc31a:false};
  $scope.disabled={vd10a:false};

  $scope.active={menu:false};

  //system select menu items
  $scope.vc31 = function() {
      $scope.disabled={vc31:true};
      $scope.active={vc31:true};
  }
  $scope.vc20a = function() {
      $scope.disabled={vc20a:true};
      $scope.active={vc20a:true};
  }
  $scope.vc25a = function() {
      $scope.disabled={vc25a:true};
      $scope.active={vc25a:true};
  }
  $scope.vc30a = function() {
      $scope.disabled={vc30a:true};
      $scope.active={vc30a:true};
  }
  $scope.vc31a = function() {
      $scope.disabled={vc31a:true};
      $scope.active={vc31a:true};
  }
  $scope.vd10a = function() {
      $state.go('app.system-main');
      $scope.disabled={vd10a:true};
      $scope.active={vd10a:true};
  }

})


.controller('SlideController', function($scope) {

			function showBanner(index) {
				var oldElm = document.querySelector('.slider ion-slide.slider-slide.current');
				var q = '.slider ion-slide.slider-slide[data-index="' + index + '"]';
				var elm = document.querySelector(q);


        $scope.nextSlide = function() {
          $scope.activeSlide = index + 1 ;
        };
        $scope.prevSlide = function() {
          $scope.activeSlide = index - 1 ;
        };
        $scope.closeSlide = function() {
          $scope.activeSlide = index = 0 ;
        };

        //Go to Feature from icon click
        $scope.feature1 = function() {
          $scope.activeSlide = index = 1 ;
        };
        $scope.feature2 = function() {
          $scope.activeSlide = index = 2 ;
        };
        $scope.feature3 = function() {
          $scope.activeSlide = index = 3 ;
        };
        $scope.feature4 = function() {
          $scope.activeSlide = index = 4 ;
        };

        $scope.prevButton={Ctrl:false};
        $scope.nextButton={Ctrl:false};

        $scope.featureSlide={Ctrl:true};
        console.log("This slide is " + index);

				// Remove class "current"
				if (null !== oldElm) {
					oldElm.classList.remove("current");
				};
				// Add class "current" to current slide
				if (null !== elm) {
					elm.classList.add("current");
				};
        // Adds prev next slide ctrls with close button
        if ( index >= 1  ) {
          $scope.featureSlide={Ctrl:false};
        };
        if ( index == 1  ) {
            $scope.prevButton={Ctrl:true};
        };
        if ( index == 4  ) {
          $scope.nextButton={Ctrl:true};
        };

			};
      			$scope.activeSlide = 0;

            setTimeout(function() {
      				showBanner($scope.activeSlide);
      			}, 0);

			$scope.slideChanged = showBanner;
})

.controller('DataSlideController', function($scope, $ionicModal, $state, $ionicSlideBoxDelegate) {

  // Description HELX Overview Modal Controller
  $ionicModal.fromTemplateUrl('templates/helx-usability.html', {
    scope: $scope
    }).then(function(modal) {
      $scope.modal = modal;
      if($state.is('app.data')){
           $scope.modal.show();
        }
  });
  $scope.close={Modal:false};

  $scope.usabilityModal = function($usabilityModalEvent) {
    $scope.modal.show($usabilityModalEvent);
  }
  $scope.closeusabilityModal = function($usabilityModalEvent) {
    $scope.modal.hide($usabilityModalEvent);
    $scope.close={Modal:true};
  }
  $scope.$on('modal.hidden', function() {
    $scope.close={Modal:true};
  });

			function showDataSlide(index) {

        $scope.prevSlide = function() {
          $scope.activeSlide = index - 1 ;
        };
        $scope.nextSlide = function() {
          $scope.activeSlide = index + 1 ;
        };
        $scope.closeSlide = function() {
          $scope.activeSlide = index = 0 ;
        };
			}
      			$scope.activeSlide = 0;

            setTimeout(function() {
      				showDataSLide($scope.activeSlide);
      			}, 0);

			$scope.slideChanged = showDataSlide;
})

.controller( 'HideCtrl', function($scope, $state, $stateParams ) {
  $scope.$on('$ionicView.enter', function(e) {
      $scope.hideMenu = true;
      console.log('Sub Menu button was removed, sucka!');
   });
});
