// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'HELX' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'helx.controllers' is found in controllers.js
angular.module('HELX',
[
  'ionic',
  'helx.controllers',
  'ionic.ion.imageCacheFactory',
  'quizApp',
  'templates',
  'ngCookies'
])

.run(function($ionicPlatform, $ImageCacheFactory) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
    window.shouldRotateToOrientation = function(degrees) {
      return true;
    }
       $ImageCacheFactory.Cache([
            "../img/helx-details/HELX_WorkflowInnovation.jpg",
            "../img/helx-details/HELX_GelWarmer.jpg",
            "../img/helx-details/HELX_ControlPanel.jpg",
            "../img/helx-details/HELX_WorkflowInnovation.jpg",

        ]).then(function(){
            console.log("Images done loading!");
        },function(failed){
            console.log("An image filed: "+failed);
        });
    })
})


.config(function($stateProvider, $urlRouterProvider) {
  $stateProvider

  .state('app', {
		url: '/app',
		templateUrl: 'helx-header.html',
		controller: 'AppCtrl'
  })

  .state('app.splash', {
    url: '/',
    views: {
      'headerContent': {
        templateUrl: 'helx-splash.html'
      }
    }
  })

  .state('app.launch', {
    url: '/launch',
    views: {
        templateUrl: 'helx-launch.html'
    }
  })

   .state('app.main', {
    url: '/main',
    views: {
      'headerContent': {
        templateUrl: 'helx-main.html'
      }
    }
  })

  // Sales Quiz Pages
  .state('app.quizintro', {
    url: '/sales-quiz-intro',
    views: {
      'headerContent': {
        templateUrl: 'helx-quiz-intro.html'
      }
    }
  })
  .state('app.quiz', {
    url: '/quiz',
    views: {
      'headerContent': {
        templateUrl: 'quiz/helx-quiz.html',
        controller: 'QuizCtrl'
      }
    }
  })

  // Workflow Simulation Pages
  .state('app.workflow', {
    url: '/workflow',
    views: {
      'headerContent': {
        templateUrl: 'helx-workflow.html'
      }
    }
  })

 // Data Proof Pages
  .state('app.data', {
    url: '/data',
    views: {
      'headerContent': {
        templateUrl: 'helx-data-proof.html'
      }
    }
  })
  .state('app.usability', {
    url: '/usability',
    views: {
      'headerContent': {
        templateUrl: 'helx-usability.html'
      }
    }
  })

 // Semiens Ultrasound Product Pages
  .state('app.products', {
    url: '/products',
	views: {
      'headerContent': {
    	templateUrl: 'helx-products.html'
	  }
	}
  })
  .state('app.acuson', {
    url: '/acuson',
  views: {
      'headerContent': {
      templateUrl: 'products/helx-single-products.html'
    }
  }
  })

  .state('app.products.ultrasound', {
    url: '/ultrasound',
    views: {
      'productsContent': {
        templateUrl: 'helx-ultrasound.html'
      }
    },
    onEnter: function(){

              //console.log('One enter loaded this log.');
    }
  })

// Single Product Pages
  .state('app.acuson.s3000', {
    url: '/s3000',
    views: {
      'singleproductsContent': {
        templateUrl: 'products/helx-s3000.html'
      }
    }
  })

  .state('app.acuson.s2000', {
    url: '/s2000',
    views: {
      'singleproductsContent': {
        templateUrl: 'products/helx-s2000.html'
      }
    }
  })

  .state('app.acuson.s1000', {
    url: '/s1000',
    views: {
      'singleproductsContent': {
        templateUrl: 'products/helx-s1000.html'
      }
    }
  })

// Resource Library Pages
	.state('app.library', {
      url: '/library',
      views: {
        'headerContent': {
          templateUrl: 'library/library-main.html'
        }
      }
    })

    .state('app.clinical', {
      url: '/clinical-images',
      views: {
        'headerContent': {
          templateUrl: 'library/clinical.html'
        }
      }
    })

    .state('app.literature', {
      url: '/clinical-literature',
      views: {
        'headerContent': {
          templateUrl: 'library/literature.html'
        }
      }
    })

    .state('app.videos', {
      url: '/clinical-videos',
      views: {
        'headerContent': {
          templateUrl: 'library/videos.html'
        }
      }
    })

    // Siemens Ultrasound Information
    .state('app.siemens-information', {
        url: '/siemens-information',
        views: {
          'headerContent': {
            templateUrl: 'helx-siemens-ultrasound-info.html'
          }
        }
      })

    .state('app.contact', {
        url: '/contact',
        views: {
          'headerContent': {
            templateUrl: 'helx-contact.html'
          }
        }
      })

    .state('app.learnmore', {
          url: '/learn-more',
          views: {
            'headerContent': {
              templateUrl: 'helx-learn-more.html'
            }
          }
        })

    .state('app.system', {
        url: '/system',
        views: {
        'headerContent': {
            templateUrl: 'system-tree/helx-family-tree.html'
          }
        }
    })
    .state('app.system-main', {
        url: '/system-main',
        views: {
        'headerContent': {
            templateUrl: 'system-tree/helx-family-tree-main.html'
          }
        }
    })

  // if none of the above states are matched, use this as the fallback
  $urlRouterProvider.otherwise('/app/');

});
