
// Quiz Controller
angular.module('quizApp', ['ngCookies'])

.controller('QuizCtrl', function (
  $scope, $http, $location,
  $timeout, $ionicModal,
  $state, $ionicSlideBoxDelegate,
  $cookieStore, $cookies
  ) {

    $scope.mode = 'quiz';
    $scope.itemsPerPage = 1;

    $scope.show={result:true};
    $scope.show={question:false};

    // Hgh Streak Stars and Stats
    $scope.high_streak = 0;
    $scope.stars =  [
      { src: '/img/quiz-star-outline.png', id: 1 },
      { src: '/img/quiz-star-outline.png', id: 2 },
      { src: '/img/quiz-star-outline.png', id: 3 },
      { src: '/img/quiz-star-outline.png', id: 4 }
    ];

    // ngCookies Cookie store
    // $scope.lastVal = $cookieStore.get('tab'); // Get cookie
    // $cookieStore.put('tab', tabName); // Put cookie to tab from function tabName
    //also
    /*
    $cookies.put("tommy", "gun");
    var value = $cookies.get("tommy");

    $cookies.userName = 'Max Joe';
    $scope.cookiesUserName = $cookies.userName;
    $cookies.put("tommy", "gun");
    $scope.cookietechnology = $cookies.get('tommy');

    $scope.highest_streak = function () {
        var highestStreak = $cookieStore.get('highestStreak');
        if (!lhighestStreak) {
            $rootScope.highestStreak = 1;
        } else {
            $rootScope.highestStreak = highestStreak + 1;
        }
        $cookieStore.put('highestStreak', $rootScope.highestStreak);
    }
 */
    $scope.loadQuiz = function (file) {
        $http.get(file)
         .then(function (res) {
             $scope.quiz = res.data.quiz;
             $scope.questions = res.data.questions;
             $scope.totalItems = $scope.questions.length;
             $scope.currentPage = 3;

             $scope.$watch('currentPage + itemsPerPage', function () {
                 var begin = (($scope.currentPage - 1) * $scope.itemsPerPage),
                   end = begin + $scope.itemsPerPage;

                 $scope.filteredQuestions = $scope.questions.slice(begin, end);
             });
         });
    };

    $scope.loadQuiz('data/quiz.json');

    $scope.goTo = function (index) {
        if (index > 0 && index <= $scope.totalItems) {
            $scope.currentPage = index;
            $scope.mode = 'quiz';
        }
    };
    $scope.onSelect = function (option) {
        $scope.questions[$scope.currentPage - 1].Selected = option;
        $scope.questions[$scope.currentPage - 1].Answered = option.Id;

            question.Options.forEach(function (option, index, array) {
                if ($scope.toBool(option.Selected) != option.IsAnswer) {
                    return false;
                }
            });
    };
    $scope.onSubmit = function () {
        var answers = [];
        $scope.questions.forEach(function (q, index) {
            answers.push({ 'QuizId': $scope.quiz.Id, 'QuestionId': q.Id, 'Answered': q.Answered });
        });
        // Post your data to the server here. answers contains the questionId and the users' answer.
        //$http.post('api/Quiz/Submit', answers).success(function (data, status) {
        //    alert(data);
        //});
        console.log(answers);
        $scope.mode = 'result';
    };
    $scope.pageCount = function () {
        return Math.ceil($scope.questions.length / $scope.itemsPerPage);
    };

    $scope.Correct = function (index, timeout) {
      var max = 2;
        $scope.high_streak += 5;
        $scope.currentPage = 1;
        console.log('This is correct' +  Math.floor(3)+Math.random() );

        // for star changes and high streak counts

       if ($scope.high_streak == 25 ) {
         $scope.stars =  [
           { src: '/img/quiz-star.png', id: 1 },
           { src: '/img/quiz-star-outline.png', id: 2 },
           { src: '/img/quiz-star-outline.png', id: 3 },
           { src: '/img/quiz-star-outline.png', id: 4 }
         ];
          console.log(' WOW you reached 25 Points, here take a star.');
        }else if ( $scope.high_streak == 50  ) {
          $scope.stars =  [
            { src: '/img/quiz-star.png', id: 1 },
            { src: '/img/quiz-star.png', id: 2 },
            { src: '/img/quiz-star-outline.png', id: 3 },
            { src: '/img/quiz-star-outline.png', id: 4 }
          ];
            console.log(' WOW you reached 50 Points, here take a star.');
        }else if ( $scope.high_streak == 75  ) {
          $scope.stars =  [
            { src: '/img/quiz-star.png', id: 1 },
            { src: '/img/quiz-star.png', id: 2 },
            { src: '/img/quiz-star.png', id: 3 },
            { src: '/img/quiz-star-outline.png', id: 4 }
          ];
            console.log(' WOW you reached 75 Points, here take a star.');
        }else if ( $scope.high_streak == 100  ) {
          $scope.stars =  [
            { src: '/img/quiz-star.png', id: 1 },
            { src: '/img/quiz-star.png', id: 2 },
            { src: '/img/quiz-star.png', id: 3 },
            { src: '/img/quiz-star.png', id: 4 }
          ];
            console.log(' WOW you reached 100 Points, here take a star.');
        }

        $timeout(function () {
            $scope.currentPage = Math.floor(Math.random()*max+4);
        }, 800);
    };

    $scope.Wrong = function (index) {

        $scope.show={result: true};
        $scope.show={question:true};

        $scope.high_streak = 0;
        console.log('This is wrong');
    };

});
